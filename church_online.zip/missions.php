<?php
include('include/header.php');
?>
 <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Missions</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
UCC-Bwaise Missions Page-->
<div class="container events-area">
<table border="1" >
	<tr>
		<th>Dates</th>
		<th>Church</th>
		<th>Location</th>
	</tr>
	<tr>
		<td>28th January</td>
		<td>Miracle Assembly</td>
		<td>Jinja, Eastern Uganda</td>
	</tr>

	<tr>
		<td>28th January</td>
		<td>Miracle Assembly</td>
		<td>Jinja, Eastern Uganda</td>
	</tr>

	<tr>
		<td>28th January</td>
		<td>Miracle Assembly</td>
		<td>Jinja, Eastern Uganda</td>
	</tr>

	<tr>
		<td>28th January</td>
		<td>Miracle Assembly</td>
		<td>Jinja, Eastern Uganda</td>
	</tr>

	<tr>
		<td>28th January</td>
		<td>Miracle Assembly</td>
		<td>Jinja, Eastern Uganda</td>
	</tr>

	<tr>
		<td>28th January</td>
		<td>Miracle Assembly</td>
		<td>Jinja, Eastern Uganda</td>
	</tr>

	<tr>
		<td>28th January</td>
		<td>Miracle Assembly</td>
		<td>Jinja, Eastern Uganda</td>
	</tr>
</table>
</div>
<?php
include('include/footer.php');
?>