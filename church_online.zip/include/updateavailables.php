

            <div class="col-md-12" style="background-color:#fff; border: solid #D9D9D9 1px; padding: 10px; padding-top: 5px; box-shadow: #9F9F9F 2px 3px 5px; margin-top: 10px; height:700px;">
            

    
        <div class="panel panel-primary">
            <div class="panel-heading panel-title text-center wow fadeInDown">
                <span style="font-weight:bold; font-family:verdana;"><i class="glyphicon glyphicon-list-alt"></i> SHARED GOSPEL POST</span>
            </div>
            <div class="panel-body" style="background-color:#fff;">
                 <!--   Basic Table  -->
              <table class="table table-responsive table-hover table-bordered table-condensed table-striped wow fadeInDown" width="100%">
              	<thead>
                	<tr style="background-color:#000; color:#FFF;">
                        <td style="text-align:center; width:auto;" class="wow fadeInDown">DATE</td>
                    	<td style="text-align:center; width:auto;" class="wow fadeInDown">TITLE</td>
                        <td style="text-align:center; width:auto;" class="wow fadeInDown">DESCRIPTION</td>
                        <td style="text-align:center; width:auto;" class="wow fadeInDown">ACTION</td>
                        
                    </tr>
                    <tbody>
                    <?php include('include/dbconn.php');?>
                    <div class="container">
                    <?php
					$id = 0;
					$sql = ("SELECT *  FROM ucctbl order by id DESC") or die (mysqli_error());
                    $result=mysqli_query($con, $sql);
					if(mysqli_num_rows($result)>0){
						while($row = mysqli_fetch_assoc($result)){
							
                            $dat = $row['dat'];
							$title = $row['title'];
							$des = $row['des'];
							//$image = $row['image'];?>
                    	<tr style="font-size:16px; cursor:pointer;">
                            <td class="wow fadeInDown"> <center><strong><?php echo $row['dat'];?></strong></center></td>

                        	<td class="wow fadeInDown"> <center><strong><?php echo $row['title'];?></strong></center></td>
                            <td class="wow fadeInDown"> <center><strong><?php echo $row['des'];?></strong></center></td>
                            <td class="wow fadeInDown"><center><a href="#updateModal<?php echo $id;?>" data-toggle="modal" data-target="#updateModal<?php echo $id;?>" class="btn btn-default">Update</a> | <a href="#deleteModal<?php echo $id;?>" data-toggle="modal" data-target="#deleteModal<?php echo $id;?>" class="btn btn-danger"> Delete</a></center></td>
                        </tr>
                       <?php include('updateModal.php')?>
                       <?php include('deleteModal.php')?>
                        <?php }}?>
                        </div>
                    </tbody>
                </thead>
              
              </table>
                  <!-- End  Basic Table  -->
       
        </div>
    </div>
</div> 
