<?php
include('include/admin_header.php');
?>

<?php 
    include('include/updateavailables.php');
   
?>

<br>
<!--*************************************************** FOOTERS **********************************************-->

</script>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>